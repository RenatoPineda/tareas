package com.example.climaapp

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etCiudad = findViewById<EditText>(R.id.etCiudad)
        val btnBuscar = findViewById<Button>(R.id.btnBuscar)
        val tvResultado = findViewById<TextView>(R.id.tvResultado)

        btnBuscar.setOnClickListener {
            val ciudad = etCiudad.text.toString().lowercase()

            val resultado = when (ciudad) {
                "zacapa" -> "🌡️ 34°C\n☀️ Muy caluroso"
                "guatemala" -> "🌡️ 24°C\n🌤️ Parcialmente nublado"
                "antigua" -> "🌡️ 22°C\n🌥️ Nublado"
                "peten" -> "🌡️ 30°C\n🌧️ Lluvia"
                else -> "🌡️ 25°C\n🌤️ Clima normal"
            }

            tvResultado.text = resultado
        }
    }
}