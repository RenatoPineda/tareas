package com.umg.agrogestpla

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AgroGestPLAApp() }
    }
}

// Colores
val VerdePrincipal = Color(0xFF6B8E00)
val AzulBoton = Color(0xFF7DA2D6)
val GrisCaja = Color(0xFFE5E5E5)

sealed class Screen {
    object Login : Screen()
    object Menu : Screen()
    object ControlRiego : Screen()
    object ControlClima : Screen()
    object Ventas : Screen()
    object Cultivos : Screen()
    object Comunidad : Screen()
    object Inventario : Screen()
}

@Composable
fun AgroGestPLAApp() {
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Login) }

    // Estados Globales
    var nombreCultivo by rememberSaveable { mutableStateOf("Maíz") }
    var frecuenciaRiego by rememberSaveable { mutableStateOf("Cada 3 días") }
    var proximoRiego by rememberSaveable { mutableStateOf("25/03/2026") }
    var recordatorioActivo by rememberSaveable { mutableStateOf(true) }
    var cultivoVendido by rememberSaveable { mutableStateOf("Melón") }
    var cantidadVendida by rememberSaveable { mutableStateOf("200") }
    var precioUnidad by rememberSaveable { mutableStateOf("8.00") }
    var areaCultivo by rememberSaveable { mutableStateOf("2 manzanas") }
    var fechaSiembra by rememberSaveable { mutableStateOf("18/03/2026") }
    var ubicacion by rememberSaveable { mutableStateOf("Zacapa") }

    MaterialTheme {
        when (currentScreen) {
            Screen.Login -> LoginScreen { currentScreen = Screen.Menu }
            Screen.Menu -> MenuScreen { currentScreen = it }
            Screen.ControlRiego -> ControlRiegoScreen(
                nombreCultivo, frecuenciaRiego, proximoRiego, recordatorioActivo,
                { nombreCultivo = it }, { frecuenciaRiego = it }, { proximoRiego = it }, { recordatorioActivo = it }
            ) { currentScreen = Screen.Menu }
            Screen.ControlClima -> ControlClimaScreen(proximoRiego) { currentScreen = Screen.Menu }
            Screen.Ventas -> VentasScreen(
                cultivoVendido, cantidadVendida, precioUnidad,
                { cultivoVendido = it }, { cantidadVendida = it }, { precioUnidad = it }
            ) { currentScreen = Screen.Menu }
            Screen.Cultivos -> CultivosScreen(
                nombreCultivo, areaCultivo, fechaSiembra, ubicacion,
                { nombreCultivo = it }, { areaCultivo = it }, { fechaSiembra = it }, { ubicacion = it }
            ) { currentScreen = Screen.Menu }
            Screen.Comunidad -> ComunidadScreen { currentScreen = Screen.Menu }
            Screen.Inventario -> InventarioScreen { currentScreen = Screen.Menu }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppTopBar(title: String, onBack: (() -> Unit)? = null) {
    TopAppBar(
        title = { Text(title, color = Color.White, fontWeight = FontWeight.Bold) },
        navigationIcon = {
            if (onBack != null) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, "Volver", tint = Color.White)
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = VerdePrincipal)
    )
}

@Composable
fun LoginScreen(onContinue: () -> Unit) {
    var correo by rememberSaveable { mutableStateOf("") }
    val context = LocalContext.current
    Scaffold(topBar = { AppTopBar("AgroGestPLA") }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), Arrangement.Center, Alignment.CenterHorizontally) {
            Text("Crea una cuenta", fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(correo, { correo = it }, label = { Text("correo@ejemplo.com") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(16.dp))
            Button({ if (correo.isBlank()) Toast.makeText(context, "Escribe un correo", Toast.LENGTH_SHORT).show() else onContinue() }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(Color.Black)) { Text("Continuar") }
            Spacer(Modifier.height(10.dp))
            Button({ onContinue() }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(Color.Black)) { Text("Continuar sin cuenta") }
        }
    }
}

@Composable
fun MenuScreen(onNavigate: (Screen) -> Unit) {
    Scaffold(topBar = { AppTopBar("AGROGESTPLA") }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp).verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.fillMaxWidth().height(80.dp).background(VerdePrincipal.copy(0.2f), RoundedCornerShape(12.dp)), Alignment.Center) {
                Text("Gestión para agricultores", fontWeight = FontWeight.Bold, color = VerdePrincipal)
            }
            Spacer(Modifier.height(20.dp))
            val items = listOf(
                "Registrar Cultivo" to Screen.Cultivos,
                "Control de Riego" to Screen.ControlRiego,
                "Control del Clima" to Screen.ControlClima,
                "Registro de Ventas" to Screen.Ventas,
                "Inventario" to Screen.Inventario,
                "Comunidad" to Screen.Comunidad
            )
            items.forEach { (text, screen) ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { onNavigate(screen) }, colors = CardDefaults.cardColors(Color(0xFFD4D4D4))) {
                    Text(text, Modifier.padding(16.dp))
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SimpleDropdown(label: String, selected: String, options: List<String>, onSelect: (String) -> Unit) {
    var exp by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(exp, { exp = !exp }) {
        OutlinedTextField(selected, {}, Modifier.menuAnchor().fillMaxWidth(), readOnly = true, label = { Text(label) }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(exp) }, colors = TextFieldDefaults.colors(focusedContainerColor = GrisCaja, unfocusedContainerColor = GrisCaja))
        ExposedDropdownMenu(exp, { exp = false }) {
            options.forEach { DropdownMenuItem({ Text(it) }, { onSelect(it); exp = false }) }
        }
    }
}

@Composable
fun ControlRiegoScreen(c: String, f: String, p: String, r: Boolean, onC: (String) -> Unit, onF: (String) -> Unit, onP: (String) -> Unit, onR: (Boolean) -> Unit, onBack: () -> Unit) {
    Scaffold(topBar = { AppTopBar("Control de Riego", onBack) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp).verticalScroll(rememberScrollState())) {
            SimpleDropdown("Cultivo", c, listOf("Maíz", "Melón", "Frijol"), onC)
            Spacer(Modifier.height(12.dp))
            SimpleDropdown("Frecuencia", f, listOf("Cada día", "Cada 3 días", "Semanal"), onF)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(p, onP, label = { Text("Próximo riego") }, modifier = Modifier.fillMaxWidth())
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("Recordatorio")
                Switch(r, onR)
            }
            Button({ }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(AzulBoton)) { Text("Guardar") }
        }
    }
}

@Composable
fun ControlClimaScreen(p: String, onBack: () -> Unit) {
    Scaffold(topBar = { AppTopBar("Control Clima", onBack) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Card(Modifier.fillMaxWidth().height(100.dp), colors = CardDefaults.cardColors(Color(0xFFD6B36A))) {
                Box(Modifier.fillMaxSize(), Alignment.Center) { Text("Zacapa, Guatemala", color = Color.White, fontWeight = FontWeight.Bold) }
            }
            Text("Próximo riego: $p", Modifier.padding(top = 16.dp))
            Card(Modifier.fillMaxWidth().padding(top = 16.dp), colors = CardDefaults.cardColors(Color(0xFFD8BE54))) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Warning, null); Spacer(Modifier.width(8.dp)); Text("Alerta: Sequía alta")
                }
            }
        }
    }
}

@Composable
fun VentasScreen(c: String, cant: String, p: String, onC: (String) -> Unit, onCant: (String) -> Unit, onP: (String) -> Unit, onBack: () -> Unit) {
    val total = (cant.toDoubleOrNull() ?: 0.0) * (p.toDoubleOrNull() ?: 0.0)
    Scaffold(topBar = { AppTopBar("Ventas", onBack) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            SimpleDropdown("Cultivo", c, listOf("Melón", "Maíz"), onC)
            OutlinedTextField(cant, onCant, label = { Text("Cantidad") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            OutlinedTextField(p, onP, label = { Text("Precio") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
            Text("Total: Q ${String.format("%.2f", total)}", Modifier.padding(vertical = 16.dp), fontWeight = FontWeight.Bold)
            Button({ }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(AzulBoton)) { Text("Guardar Venta") }
        }
    }
}

@Composable
fun CultivosScreen(n: String, a: String, f: String, u: String, onN: (String) -> Unit, onA: (String) -> Unit, onF: (String) -> Unit, onU: (String) -> Unit, onBack: () -> Unit) {
    Scaffold(topBar = { AppTopBar("Cultivos", onBack) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            OutlinedTextField(n, onN, label = { Text("Nombre") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(a, onA, label = { Text("Área") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(f, onF, label = { Text("Fecha") }, modifier = Modifier.fillMaxWidth())
            SimpleDropdown("Ubicación", u, listOf("Zacapa", "Chiquimula"), onU)
            Button({ }, Modifier.fillMaxWidth().padding(top = 16.dp), colors = ButtonDefaults.buttonColors(AzulBoton)) { Text("Guardar") }
        }
    }
}

@Composable
fun ComunidadScreen(onBack: () -> Unit) {
    Scaffold(topBar = { AppTopBar("Comunidad", onBack) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            listOf("Amilcar David", "Engel Leonor", "Renato Pineda").forEach {
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(Color(0xFFBDBDBD))) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AccountCircle, null, Modifier.size(40.dp))
                        Text(it, Modifier.padding(start = 12.dp), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun InventarioScreen(onBack: () -> Unit) {
    Scaffold(topBar = { AppTopBar("Inventario", onBack) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            listOf("Fertilizante" to "50 kg", "Semillas" to "10 kg").forEach { (n, c) ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(GrisCaja)) {
                    Row(Modifier.padding(16.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                        Text(n, fontWeight = FontWeight.Bold); Text(c)
                    }
                }
            }
        }
    }
}
